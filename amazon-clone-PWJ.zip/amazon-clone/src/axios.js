// axios allows us to import APIs

import axios from "axios";

const instance = axios.create({
  baseURL: "...", // The API (cloud function) URL
});

export default instance;
